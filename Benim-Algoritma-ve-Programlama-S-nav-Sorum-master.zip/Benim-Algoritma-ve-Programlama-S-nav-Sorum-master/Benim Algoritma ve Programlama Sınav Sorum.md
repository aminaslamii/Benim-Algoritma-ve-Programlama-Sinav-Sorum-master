# Algoritma Ödev 4. Mohammad Amin Aslami
